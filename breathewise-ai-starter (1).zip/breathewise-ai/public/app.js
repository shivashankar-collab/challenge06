const fallback = {
  summary: "Based on your context, prioritize lower-exposure travel during polluted periods, keep indoor air clean, and choose simple lower-emission alternatives.",
  actions: [
    {
      title: "Shift the commute",
      detail: "If possible, travel outside the busiest pollution window or choose public transport for part of the trip.",
      reason: "Reducing time in dense traffic can reduce direct exposure to roadside pollution.",
      priority: "high"
    },
    {
      title: "Create a clean-air room",
      detail: "Keep doors and windows closed during the worst outdoor-air periods and use filtration if available.",
      reason: "A cleaner indoor zone gives the household a lower-exposure place to spend time.",
      priority: "high"
    },
    {
      title: "Swap one high-emission habit",
      detail: "Combine errands into one trip and avoid unnecessary idling or short vehicle trips.",
      reason: "Fewer trips can reduce both personal exposure and avoidable emissions.",
      priority: "medium"
    }
  ],
  indoor: [
    "Use the kitchen exhaust while cooking and keep the cooking area ventilated.",
    "Reduce indoor smoke sources such as incense, tobacco smoke and unnecessary burning.",
    "Ventilate when outdoor air is cleaner rather than leaving windows open continuously."
  ],
  sustainableSwaps: [
    "Combine errands instead of making multiple short vehicle trips.",
    "Choose walking or cycling when air quality and route safety make it appropriate.",
    "Use public transport for a portion of regular commutes when practical."
  ],
  whyItMatters: "The strongest benefit comes from matching your routine to pollution conditions: spend less time in polluted hotspots, improve the indoor environment, and avoid unnecessary emissions.",
  disclaimer: "General information only. This tool does not diagnose or treat medical conditions."
};

const $ = (id) => document.getElementById(id);

function aqiInfo(aqi) {
  if (aqi <= 50) return ["Good", "Air quality is generally good. Normal outdoor activity is reasonable."];
  if (aqi <= 100) return ["Moderate", "Most people can continue normal activity; sensitive people may prefer lower-exposure periods."];
  if (aqi <= 150) return ["Unhealthy for sensitive groups", "Reduce prolonged outdoor exertion and plan lower-exposure travel."];
  if (aqi <= 200) return ["Unhealthy", "Consider reducing prolonged outdoor activity and prioritize cleaner indoor spaces."];
  if (aqi <= 300) return ["Very unhealthy", "Limit prolonged outdoor exposure and follow local public-health guidance."];
  return ["Hazardous", "Avoid unnecessary outdoor exposure and follow official local health guidance."];
}

function updateAQI() {
  const aqi = Number($("aqi").value || 0);
  const [label, message] = aqiInfo(aqi);
  $("aqiValue").textContent = aqi;
  $("heroAqi").textContent = aqi;
  $("heroLabel").textContent = label;
  $("aqiPill").textContent = label.toUpperCase();
  $("aqiMessage").textContent = message;
}

function renderPlan(plan) {
  $("planSummary").textContent = plan.summary || fallback.summary;

  $("actions").innerHTML = (plan.actions || []).map((a, i) => `
    <article class="action">
      <div class="num">0${i + 1} · ${(a.priority || "medium").toUpperCase()}</div>
      <h4>${escapeHtml(a.title || "Recommended action")}</h4>
      <p>${escapeHtml(a.detail || "")}</p>
      <p class="reason">${escapeHtml(a.reason || "")}</p>
    </article>
  `).join("");

  $("indoorList").innerHTML = (plan.indoor || fallback.indoor)
    .map(x => `<li>${escapeHtml(x)}</li>`).join("");

  $("swapList").innerHTML = (plan.sustainableSwaps || fallback.sustainableSwaps)
    .map(x => `<li>${escapeHtml(x)}</li>`).join("");

  $("whyItMatters").textContent = plan.whyItMatters || fallback.whyItMatters;
  $("disclaimer").textContent = plan.disclaimer || fallback.disclaimer;

  const aqi = Number($("aqi").value || 0);
  const score = Math.max(25, Math.min(94, 94 - Math.round(aqi * 0.14)));
  $("impactScore").textContent = score;
  $("meterFill").style.width = `${score}%`;
}

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#039;"
  }[c]));
}

async function generatePlan() {
  const btn = $("generateBtn");
  btn.disabled = true;
  btn.querySelector("span:first-child").textContent = "Generating…";
  $("status").textContent = "Gemini is creating a personalized plan…";

  const payload = {
    city: $("city").value,
    aqi: Number($("aqi").value || 0),
    commute: $("commute").value,
    outdoorHours: Number($("outdoorHours").value || 2),
    household: $("household").value,
    concerns: $("concerns").value
  };

  try {
    const response = await fetch("/api/air-plan", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Unable to generate plan.");

    renderPlan(data);
    $("status").textContent = "Plan generated by Gemini.";
  } catch (error) {
    renderPlan(fallback);
    $("status").textContent = `Demo mode: ${error.message}`;
  } finally {
    btn.disabled = false;
    btn.querySelector("span:first-child").textContent = "Generate my plan";
  }
}

$("aqi").addEventListener("input", updateAQI);
$("generateBtn").addEventListener("click", generatePlan);

updateAQI();
renderPlan(fallback);