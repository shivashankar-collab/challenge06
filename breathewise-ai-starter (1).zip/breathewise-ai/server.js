import express from "express";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;
const MODEL = process.env.GEMINI_MODEL || "gemini-3.8-flash";

app.use(express.json({ limit: "1mb" }));
app.use(express.static("public"));

const systemPrompt = `
You are BreatheWise AI, an urban air-quality assistant.
Your job is to give practical, conservative, non-diagnostic advice for reducing
pollution exposure and choosing lower-emission routines.

Return JSON only with this shape:
{
  "summary": "short personalized summary",
  "actions": [
    {"title":"...", "detail":"...", "reason":"...", "priority":"high|medium|low"}
  ],
  "indoor": ["...", "..."],
  "sustainableSwaps": ["...", "..."],
  "whyItMatters": "brief explanation",
  "disclaimer": "short safety disclaimer"
}

Do not invent live AQI measurements. Treat the AQI supplied by the user as the
current input. Avoid medical diagnosis. For severe symptoms, advise contacting
a qualified healthcare professional or emergency service.
`;

app.post("/api/air-plan", async (req, res) => {
  if (!process.env.GEMINI_API_KEY) {
    return res.status(503).json({
      error: "Gemini API key is not configured. Copy .env.example to .env and add GEMINI_API_KEY."
    });
  }

  const {
    city = "Bengaluru",
    aqi = 150,
    commute = "Car",
    outdoorHours = 2,
    household = "2 adults",
    concerns = "general"
  } = req.body || {};

  const userPrompt = `
Create an air-safe plan for:
City: ${city}
AQI supplied by user: ${aqi}
Commute: ${commute}
Typical outdoor exposure: ${outdoorHours} hours/day
Household: ${household}
Main concerns: ${concerns}

Prioritize actionable steps for today. Explain why each step helps.
`;

  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": process.env.GEMINI_API_KEY
        },
        body: JSON.stringify({
          systemInstruction: {
            parts: [{ text: systemPrompt }]
          },
          contents: [
            {
              role: "user",
              parts: [{ text: userPrompt }]
            }
          ],
          generationConfig: {
            responseMimeType: "application/json",
            temperature: 0.4,
            maxOutputTokens: 1200
          }
        })
      }
    );

    const data = await response.json();

    if (!response.ok) {
      return res.status(response.status).json({
        error: data?.error?.message || "Gemini request failed."
      });
    }

    const raw = data?.candidates?.[0]?.content?.parts?.[0]?.text;
    if (!raw) {
      return res.status(502).json({ error: "Gemini returned no text." });
    }

    let plan;
    try {
      plan = JSON.parse(raw);
    } catch {
      return res.status(502).json({ error: "Gemini returned invalid JSON.", raw });
    }

    res.json(plan);
  } catch (error) {
    res.status(500).json({ error: error.message || "Unexpected server error." });
  }
});

app.listen(PORT, () => {
  console.log(`BreatheWise AI running at http://localhost:${PORT}`);
});