# BreatheWise AI

A Hack2Skill PromptWars Challenge 06 prototype: a GenAI-powered urban air-quality assistant.

## What it demonstrates

- Personalized low-exposure routines
- Indoor air-quality hacks
- Sustainable swaps
- "Why it matters" explanations
- AQI-aware UI
- Gemini-powered plan generation
- Demo/fallback mode when Gemini is not configured

## Tech stack

- HTML, CSS, JavaScript
- Node.js + Express
- Google Gemini API
- Google AI Studio for obtaining/configuring the Gemini API key

The Gemini API call is made on the server so the API key is not exposed in browser code.

## Run locally

1. Install Node.js 20+.
2. Open a terminal in this folder.
3. Install dependencies:

   npm install

4. Create `.env` from `.env.example`:

   Windows:
   copy .env.example .env

   macOS/Linux:
   cp .env.example .env

5. Put your Gemini API key into `.env`:

   GEMINI_API_KEY=your_key_here

6. Start:

   npm run dev

7. Open:

   http://localhost:3000

## Demo without an API key

The UI works in fallback/demo mode even if Gemini is not configured. Add a Gemini key to activate real AI-generated plans.

## Suggested next upgrades

1. Connect a trusted live AQI source for the selected city.
2. Add Google Maps/route context for commute recommendations.
3. Add user accounts and saved daily plans.
4. Add notifications for severe AQI.
5. Add a history chart showing AQI and routine choices over time.
6. Add an admin/demo mode for judging.
7. Record a 60–90 second walkthrough for the PromptWars submission.

## Important

Do not commit `.env` or any API key to GitHub. Treat AQI values as data from a source, and keep health guidance conservative and non-diagnostic.
